DROP TABLE IF EXISTS `#__dictionary_letters`;
DROP TABLE IF EXISTS `#__dictionary_letter_def`;

