<?php
/**
 * @version     2.0.0
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net
 **/

// No direct access.
defined('_JEXEC') or die;

jimport('joomla.application.component.controlleradmin');

/**
 * Letters list controller class.
 */
class DictionaryControllerLetters extends JControllerAdmin
{
	/**
	 * Proxy for getModel.
	 * @since	1.6
	 */
	public function getModel($name = 'letter', $prefix = 'DictionaryModel')
	{
		$model = parent::getModel($name, $prefix, array('ignore_request' => true));
		return $model;
	}
    
    
	/**
	 * Method to save the submitted ordering values for records via AJAX.
	 *
	 * @return  void
	 *
	 * @since   3.0
	 */
	public function saveOrderAjax()
	{
		// Get the input
		$input = JFactory::getApplication()->input;
		$pks = $input->post->get('cid', array(), 'array');
		$order = $input->post->get('order', array(), 'array');

		// Sanitize the input
		JArrayHelper::toInteger($pks);
		JArrayHelper::toInteger($order);

		// Get the model
		$model = $this->getModel();

		// Save the ordering
		$return = $model->saveorder($pks, $order);

		if ($return)
		{
			echo "1";
		}

		// Close the application
		JFactory::getApplication()->close();
	}

	public function export()
	{
		function generatecsv(array &$export)
		{
			if(count($export)){
				ob_start();
	   			$df = fopen("php://output", 'w');
	     	    foreach ($export as $row) {
		  		    fputcsv($df, $row);
	     		}
			   	fclose($df);
	   			return ob_get_clean();
			}
		}

		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query = "SELECT a.id,a.letter_name, b.word, b.definition FROM `#__dictionary_letters` as a LEFT OUTER JOIN `#__dictionary_letter_def` as b ON a.id=b.letter_id ";
		$db->setQuery($query);
		$results = $db->loadObjectList();

		$csv_export = array();

		for ($i=0; $i < count($results) ; $i++) { 
			$csv_export[$i] = array($results[$i]->letter_name,$results[$i]->word,$results[$i]->definition);
		}

		$fields = array("Letter Name","Word","Definition");
		array_unshift($csv_export, $fields);

		$filename = "Export" . "-" . date("d-m-Y") . ".csv";

		header('Content-Encoding: UTF-8');
     	header("content-type:application/csv;charset=UTF-8");
     	header("Content-Disposition: attachment;filename={$filename}");
		echo generatecsv($csv_export);
		exit;
	}
}