<?php
/**
 * @version     2.0.0
 * @package     com_dictionary
 * @copyright   Copyright (C) 2015. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      daniel@web-eau.net - http://www.web-eau.net
 **/
 
// no direct access
defined('_JEXEC') or die;
$doc = JFactory::getDocument();

JHtml::addIncludePath(JPATH_COMPONENT . '/helpers/html');
JHtml::_('bootstrap.tooltip');
JHtml::_('behavior.multiselect');
JHtml::_('formbehavior.chosen', 'select');

$user = JFactory::getUser();
$userId = $user->get('id');

?>
<meta name="viewport" content="width=device-width" />
<?php $doc->addStyleSheet(JUri::base() . 'components/com_dictionary/assets/css/dictionnary.css'); ?>
<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.11.1/jquery-ui.min.js"></script>
<script>
( function($) {
	$(document).ready(function() {
		$('a').on('click', function() {
			var parent_node = this.parentNode;
			console.log(parent_node);
			$(parent_node).children("div").toggle("blind");
		});
	});
} ) ( jQuery );
</script>

<?php
$db = JFactory::getDbo();
$q1 = $db->getQuery(true);
$q2 = $db->getQuery(true);

$q1 = "SELECT * FROM #__dictionary_letters ORDER BY id ASC";
$db->setQuery($q1);
$r1 = $db->loadObjectList();
$c = ceil(count($r1)/3);

$counter = 0;

echo "<div class='lexique'>";

	for($i=0; $i<count($r1); $i++)
	{
		echo '<div class="set"><h3 class="letter">'. $r1[$i]->letter_name .'</h3>';
		
		$q2 = "SELECT * FROM #__dictionary_letter_def WHERE letter_id='". $r1[$i]->id ."'";
		$db->setQuery($q2);
		$r2 = $db->loadObjectList();
		
		echo '<ul>';
		for($j=0; $j<count($r2); $j++)
		{
			echo '<div class="spoiler"><a href="#" class="link">'. $r2[$j]->word . '</a><div class="definition" style="display:none;">'. $r2[$j]->definition .'</div></div>';
		}
		echo '</ul></div>';
	}
	
echo "</div>";

?>